import assert from "node:assert/strict";
import test from "node:test";

import {
  InMemoryOutcomeJournal,
  OutcomeError,
  OutcomeLedger,
  isAccepted,
  isOpen,
  type AcceptanceVerdict,
  type ExecutionResult,
  type TaskContract,
} from "../src/outcome.js";

const contract = (overrides: Partial<TaskContract> = {}): TaskContract => ({
  requestId: "req-1",
  taskId: "TQ-tower-1",
  operatorTargetId: "TGT-2026-08-24-ryan-governed-tower-primary-rpi-greenfield",
  senderPeerId: "peer-sender",
  receiverPeerId: "peer-receiver",
  acceptance: [
    {
      checkId: "sha",
      kind: "mechanical",
      expect: "sha256:abc",
      description: "the delivered file hashes to the expected value",
    },
    { checkId: "exit", kind: "mechanical", expect: "0", description: "the consumption command exits 0" },
  ],
  consequential: false,
  ...overrides,
});

const realResult = (overrides: Partial<ExecutionResult> = {}): ExecutionResult => ({
  requestId: "req-1",
  receiverPeerId: "peer-receiver",
  evidence: ["/srv/throughline/proof/receipt.json"],
  ...overrides,
});

const passingVerdict = (acceptorPeerId = "peer-acceptor"): AcceptanceVerdict => ({
  requestId: "req-1",
  acceptorPeerId,
  observations: [
    { checkId: "sha", observed: "sha256:abc" },
    { checkId: "exit", observed: "0" },
  ],
});

let tick = 0;
const clock = () => `2026-09-13T18:00:${String(tick++).padStart(2, "0")}.000Z`;

test("a confident reply without the required result cannot complete the task", () => {
  const ledger = new OutcomeLedger(new InMemoryOutcomeJournal(), clock);
  ledger.admit(contract());
  ledger.deliver("req-1", "turn-1");
  const afterTurn = ledger.turnFinished(
    "req-1",
    "turn-1",
    "Done. I verified everything and the tower task is complete; all checks pass.",
  );

  // The paragraph is retained as evidence of the turn, and nothing more.
  assert.equal(afterTurn.state, "turn_finished");
  assert.equal(afterTurn.finishedText?.startsWith("Done."), true);
  assert.equal(isOpen(afterTurn), true);
  assert.equal(isAccepted(afterTurn), false);

  // Acceptance without a claimed result is refused, not judged.
  assert.throws(
    () => ledger.recordAcceptance(passingVerdict()),
    (error: unknown) => error instanceof OutcomeError && error.code === "NO_RESULT_CLAIMED",
  );

  // A result with no evidence is a paragraph in a different shape; refused.
  assert.throws(
    () => ledger.claimResult(realResult({ evidence: [] })),
    (error: unknown) => error instanceof OutcomeError && error.code === "NO_EVIDENCE",
  );
  assert.equal(ledger.get("req-1").state, "turn_finished");
});

test("a real result with independently passing acceptance completes the task", () => {
  const ledger = new OutcomeLedger(new InMemoryOutcomeJournal(), clock);
  ledger.admit(contract());
  ledger.deliver("req-1", "turn-1");
  ledger.turnFinished("req-1", "turn-1", "Wrote the receipt.");
  const claimed = ledger.claimResult(realResult());
  assert.equal(claimed.state, "result_claimed");
  assert.equal(isAccepted(claimed), false);

  // The receiver grading its own work is refused by identity, not by trust.
  assert.throws(
    () => ledger.recordAcceptance(passingVerdict("peer-receiver")),
    (error: unknown) => error instanceof OutcomeError && error.code === "NOT_INDEPENDENT",
  );
  assert.throws(
    () => ledger.recordAcceptance(passingVerdict("peer-sender")),
    (error: unknown) => error instanceof OutcomeError && error.code === "NOT_INDEPENDENT",
  );

  // An acceptor that skipped a check is refused; partial observation is not a verdict.
  assert.throws(
    () =>
      ledger.recordAcceptance({
        requestId: "req-1",
        acceptorPeerId: "peer-acceptor",
        observations: [{ checkId: "sha", observed: "sha256:abc" }],
      }),
    (error: unknown) => error instanceof OutcomeError && error.code === "CHECK_NOT_OBSERVED",
  );

  const accepted = ledger.recordAcceptance(passingVerdict());
  assert.equal(accepted.state, "accepted");
  assert.equal(isAccepted(accepted), true);
  assert.equal(isOpen(accepted), false);
});

test("an observed value that misses the expectation rejects even when the acceptor is independent", () => {
  const ledger = new OutcomeLedger(new InMemoryOutcomeJournal(), clock);
  ledger.admit(contract());
  ledger.deliver("req-1", "turn-1");
  ledger.turnFinished("req-1", "turn-1", "All good.");
  ledger.claimResult(realResult());
  const rejected = ledger.recordAcceptance({
    requestId: "req-1",
    acceptorPeerId: "peer-acceptor",
    observations: [
      { checkId: "sha", observed: "sha256:abc" },
      { checkId: "exit", observed: "1" },
    ],
  });
  assert.equal(rejected.state, "rejected");
  assert.equal(isAccepted(rejected), false);
});

test("duplicate delivery and duplicate claims neither lose the task nor repeat a consequential action", () => {
  const journal = new InMemoryOutcomeJournal();
  const ledger = new OutcomeLedger(journal, clock);
  ledger.admit(contract({ consequential: true }));

  // The same request delivered twice to the same turn is one delivery.
  ledger.deliver("req-1", "turn-1");
  const again = ledger.deliver("req-1", "turn-1");
  assert.deepEqual(again.receiverTurnIds, ["turn-1"]);

  // A consequential result must name its idempotency key.
  ledger.turnFinished("req-1", "turn-1", "Cutover performed.");
  assert.throws(
    () => ledger.claimResult(realResult()),
    (error: unknown) => error instanceof OutcomeError && error.code === "IDEMPOTENCY_KEY_REQUIRED",
  );

  // The claim, repeated three times, commits the consequential act once.
  const claim = realResult({ idempotencyKey: "cutover-2026-09-13" });
  ledger.claimResult(claim);
  ledger.claimResult(claim);
  const third = ledger.claimResult(claim);
  assert.deepEqual(third.committedKeys, ["cutover-2026-09-13"]);
  assert.equal(journal.readAll().filter((e) => e.type === "consequential_committed").length, 1);

  // A late-arriving finished turn for a redelivery cannot demote a claimed result.
  const late = ledger.turnFinished("req-1", "turn-2", "Cutover performed again.");
  assert.equal(late.state, "result_claimed");
});

test("interruption before acceptance leaves the task open and replay yields the same state", () => {
  const journal = new InMemoryOutcomeJournal();
  const before = new OutcomeLedger(journal, clock);
  before.admit(contract({ consequential: true }));
  before.deliver("req-1", "turn-1");
  before.turnFinished("req-1", "turn-1", "Cutover performed.");
  before.claimResult(realResult({ idempotencyKey: "cutover-2026-09-13" }));

  // The process dies here. A new ledger is rebuilt from the journal alone.
  const after = new OutcomeLedger(journal, clock);
  const recovered = after.get("req-1");
  assert.equal(recovered.state, "result_claimed");
  assert.equal(isOpen(recovered), true);
  assert.deepEqual(recovered.committedKeys, ["cutover-2026-09-13"]);

  // Re-running the receiver's claim after recovery does not repeat the act.
  after.claimResult(realResult({ idempotencyKey: "cutover-2026-09-13" }));
  assert.equal(journal.readAll().filter((e) => e.type === "consequential_committed").length, 1);

  // Acceptance after recovery completes it exactly once; a second verdict is a no-op.
  const accepted = after.recordAcceptance(passingVerdict());
  assert.equal(accepted.state, "accepted");
  const twice = after.recordAcceptance(passingVerdict());
  assert.equal(twice.state, "accepted");
  assert.equal(journal.readAll().filter((e) => e.type === "acceptance_recorded").length, 1);
});

test("interruption before any result leaves the task open rather than completed or lost", () => {
  const journal = new InMemoryOutcomeJournal();
  const before = new OutcomeLedger(journal, clock);
  before.admit(contract());
  before.deliver("req-1", "turn-1");
  before.turnFinished("req-1", "turn-1", "I believe this is complete.");

  const after = new OutcomeLedger(journal, clock);
  const recovered = after.get("req-1");
  assert.equal(recovered.state, "turn_finished");
  assert.equal(isOpen(recovered), true);
  assert.equal(isAccepted(recovered), false);
});
