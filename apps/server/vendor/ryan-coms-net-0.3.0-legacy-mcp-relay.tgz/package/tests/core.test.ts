import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";
import test from "node:test";

import {
  ComsNet,
  ComsNetError,
  InMemoryComsNetStore,
  JsonFileComsNetStore,
  MAX_TIMER_DELAY_MS,
  StaticPeerDirectory,
  clampTimerDelayMs,
  type PeerIdentity,
} from "../src/index.js";

test("lease timers clamp delays that exceed the Node.js timer range", () => {
  assert.equal(clampTimerDelayMs(Number.MAX_SAFE_INTEGER), MAX_TIMER_DELAY_MS);
  assert.equal(clampTimerDelayMs(250), 250);
  assert.equal(clampTimerDelayMs(-1), 0);
});

test("the correlated wait schedules its production lease timer inside the Node.js range", async () => {
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: Number.MAX_SAFE_INTEGER,
    now: () => 1_000,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "capture the production lease timer" },
  });
  const controller = new AbortController();
  const originalSetTimeout = globalThis.setTimeout;
  let scheduledDelay: number | undefined;
  globalThis.setTimeout = ((callback: (...args: Array<unknown>) => void, delay?: number) => {
    scheduledDelay = delay;
    return 1 as unknown as NodeJS.Timeout;
  }) as typeof globalThis.setTimeout;

  try {
    const waiting = network.waitForResult(claude, request.requestId, {
      signal: controller.signal,
    });
    await new Promise<void>((resolve) => setImmediate(resolve));
    assert.equal(scheduledDelay, MAX_TIMER_DELAY_MS);
    controller.abort();
    await assert.rejects(waiting, /aborted/i);
  } finally {
    globalThis.setTimeout = originalSetTimeout;
  }
});

const claude: PeerIdentity = {
  peerId: "claude:claude-session-1",
  threadId: "thread-claude",
  providerName: "claudeAgent",
  providerInstanceId: "claudeAgent",
  providerSessionId: "claude-session-1",
  transcriptPath: "/transcripts/claude-session-1.jsonl",
  cwd: "/work/claude",
};

const codex: PeerIdentity = {
  peerId: "codex:codex-session-1",
  threadId: "thread-codex",
  providerName: "codex",
  providerInstanceId: "codex",
  providerSessionId: "codex-session-1",
  transcriptPath: "/transcripts/codex-session-1.jsonl",
  cwd: "/work/codex",
};

function makeNetwork(maxPayloadBytes = 4096) {
  return new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    maxPayloadBytes,
  });
}

test("server-derived principal defeats a self-reported sender override", async () => {
  const network = makeNetwork();
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "hello", senderPeerId: codex.peerId },
  });

  assert.equal(request.senderPeerId, claude.peerId);
  assert.equal(request.receiverPeerId, codex.peerId);
});

test("Claude and Codex exchange one correlated request/result in both directions", async () => {
  const network = makeNetwork();

  for (const [sender, receiver] of [
    [claude, codex],
    [codex, claude],
  ] as const) {
    const request = await network.send(sender, {
      targetPeerId: receiver.peerId,
      kind: "task",
      payload: { text: `${sender.providerName} to ${receiver.providerName}` },
    });
    const delivery = await network.subscribe(receiver);
    assert.equal(delivery.length, 1);
    assert.equal(delivery[0]?.requestId, request.requestId);

    const waiting = network.waitForResult(sender, request.requestId);
    await network.complete(receiver, request.requestId, { text: "done" });
    const completed = await waiting;
    assert.equal(completed.requestId, request.requestId);
    assert.deepEqual(completed.result, { text: "done" });
  }
});

test("ordinary completion is terminal and cannot start a reply loop", async () => {
  const network = makeNetwork();
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "once" },
  });
  await network.complete(codex, request.requestId, { text: "finished turn" });

  await assert.rejects(
    network.complete(codex, request.requestId, { text: "second reply" }),
    (error: unknown) => error instanceof ComsNetError && error.code === "ALREADY_TERMINAL",
  );
  assert.equal((await network.subscribe(claude)).length, 0);
});

test("subscribe waits once for the next request without a poll loop", async () => {
  const network = makeNetwork();
  const waiting = network.subscribe(codex, { timeoutMs: 1_000 });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "wake once" },
  });
  const delivery = await waiting;
  assert.equal(delivery.length, 1);
  assert.equal(delivery[0]?.requestId, request.requestId);
});

test("subscribe closes the send-before-waiter-registration race with one store re-read", async () => {
  class RaceStore extends InMemoryComsNetStore {
    afterEmptyRead?: () => void;
    firstRead = true;
    override async listForReceiver(receiverPeerId: string) {
      if (this.firstRead) {
        this.firstRead = false;
        queueMicrotask(() => this.afterEmptyRead?.());
        return [];
      }
      return super.listForReceiver(receiverPeerId);
    }
  }
  const store = new RaceStore();
  const network = new ComsNet({
    store,
    peers: new StaticPeerDirectory([claude, codex]),
  });
  store.afterEmptyRead = () => {
    void network.send(claude, {
      targetPeerId: codex.peerId,
      kind: "race",
      payload: { text: "landed before waiter registration" },
    });
  };

  const delivery = await network.subscribe(codex, { timeoutMs: 1_000 });
  assert.equal(delivery.length, 1);
  assert.equal(delivery[0]?.kind, "race");
});

test("trusted finished-turn completion is bound to the receiver thread", async () => {
  const network = makeNetwork();
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "ordinary turn" },
  });
  await assert.rejects(
    network.completeTrustedReceiverThread(claude.threadId, request.requestId, { text: "wrong" }),
    /does not belong/i,
  );
  const completed = await network.completeTrustedReceiverThread(codex.threadId, request.requestId, {
    text: "ordinary finished turn",
  });
  assert.equal(completed.status, "completed");
});

test("trusted receiver failure releases the sender with one terminal reason", async () => {
  const network = makeNetwork();
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "ordinary turn" },
  });
  const waiting = network.waitForResult(claude, request.requestId);

  const failed = await network.failTrustedReceiverThread(
    codex.threadId,
    request.requestId,
    "receiver turn ended with status error",
  );

  assert.equal(failed.status, "failed");
  assert.equal(failed.error, "receiver turn ended with status error");
  assert.equal((await waiting).status, "failed");
  await assert.rejects(
    network.failTrustedReceiverThread(codex.threadId, request.requestId, "second failure"),
    (error: unknown) => error instanceof ComsNetError && error.code === "ALREADY_TERMINAL",
  );
});

test("an expired delivery lease makes an unclaimed request visible again", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    deliveryLeaseMs: 100,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "survive receiver restart" },
  });
  const [firstDelivery] = await network.subscribe(codex);
  assert.equal(firstDelivery?.status, "delivered");
  assert.deepEqual(await network.subscribe(codex), []);

  now += 101;
  const reclaimed = await network.subscribe(codex);
  assert.equal(reclaimed[0]?.requestId, request.requestId);
  assert.equal(reclaimed[0]?.deliveredAt, firstDelivery?.deliveredAt);
  assert.equal(reclaimed[0]?.lastClaimedAt, new Date(now).toISOString());
});

test("a stale non-terminal request is failed by the bounded lease sweep", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 100,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "must not hang forever" },
  });
  now += 101;

  const [expired] = await network.sweepExpiredRequests();
  assert.equal(expired?.requestId, request.requestId);
  assert.equal(expired?.status, "failed");
  assert.match(expired?.error ?? "", /lease expired/i);
  assert.equal((await network.waitForResult(claude, request.requestId)).status, "failed");
});

test("a healthy delivered request survives beyond the queue lease until the receiver finishes", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 100,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "ordinary agent turn longer than the queue lease" },
  });
  assert.equal((await network.subscribe(codex))[0]?.status, "delivered");

  now += 101;
  assert.deepEqual(await network.sweepExpiredRequests(), []);
  assert.equal((await network.status(claude, request.requestId)).status, "delivered");

  const completed = await network.completeTrustedReceiverThread(codex.threadId, request.requestId, {
    text: "finished after the queue lease",
  });
  assert.equal(completed.status, "completed");
  assert.deepEqual(completed.result, { text: "finished after the queue lease" });
});

test("a successfully dispatched ordinary turn survives the queue lease without subscribe", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 100,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "ThroughLine dispatches this as an ordinary turn" },
  });

  await network.markDispatchSucceeded(claude, request.requestId);
  now += 101;
  assert.deepEqual(await network.sweepExpiredRequests(), []);

  const completed = await network.completeTrustedReceiverThread(codex.threadId, request.requestId, {
    text: "ordinary finished turn after the queue lease",
  });
  assert.equal(completed.status, "completed");
  assert.deepEqual(completed.result, { text: "ordinary finished turn after the queue lease" });
});

test("a delivered request that never settles fails after the receiver-turn lease", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 100,
    receiverTurnLeaseMs: 1_000,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "receiver disappears before its turn settles" },
  });
  await network.markDispatchSucceeded(claude, request.requestId);

  now += 999;
  assert.deepEqual(await network.sweepExpiredRequests(), []);
  now += 2;

  const [expired] = await network.sweepExpiredRequests();
  assert.equal(expired?.requestId, request.requestId);
  assert.equal(expired?.status, "failed");
  assert.match(expired?.error ?? "", /receiver turn lease expired/i);
});

test("a parked correlated wait drives the receiver-turn lease without unrelated traffic", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 5,
    receiverTurnLeaseMs: 10,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "receiver disappears while sender waits" },
  });
  await network.markDispatchSucceeded(claude, request.requestId);

  const waiting = network.waitForResult(claude, request.requestId);
  await new Promise<void>((resolve) => setImmediate(resolve));
  now += 11;
  const failed = await Promise.race([
    waiting,
    new Promise<never>((_resolve, reject) =>
      setTimeout(() => reject(new Error("parked wait did not honor receiver-turn lease")), 250),
    ),
  ]);

  assert.equal(failed.status, "failed");
  assert.match(failed.error ?? "", /receiver turn lease expired/i);
});

test("reclaiming delivery does not reset the receiver-turn lease", async () => {
  let now = 1_000;
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    deliveryLeaseMs: 10,
    receiverTurnLeaseMs: 25,
    now: () => now,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "receiver repeatedly reclaims this request" },
  });
  const [first] = await network.subscribe(codex);

  now += 11;
  const [second] = await network.subscribe(codex);
  assert.equal(second?.deliveredAt, first?.deliveredAt);
  assert.notEqual(second?.lastClaimedAt, first?.lastClaimedAt);

  now += 15;
  const [expired] = await network.sweepExpiredRequests();
  assert.equal(expired?.requestId, request.requestId);
  assert.equal(expired?.status, "failed");
});

test("a concurrent terminal transition does not abort the expiry sweep", async () => {
  let now = 1_000;
  class ConcurrentSettlementStore extends InMemoryComsNetStore {
    settleRequestId?: string;
    override async list() {
      const snapshot = await super.list();
      if (this.settleRequestId !== undefined) {
        const current = this.requests.get(this.settleRequestId);
        if (current !== undefined) {
          this.requests.set(this.settleRequestId, {
            ...current,
            status: "completed",
            completedAt: new Date(now).toISOString(),
            result: { text: "won the race" },
          });
        }
        this.settleRequestId = undefined;
      }
      return snapshot;
    }
  }
  const store = new ConcurrentSettlementStore();
  const network = new ComsNet({
    store,
    peers: new StaticPeerDirectory([claude, codex]),
    receiverTurnLeaseMs: 10,
    now: () => now,
  });
  const raced = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "settles during sweep" },
  });
  const expired = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "still must expire" },
  });
  await network.markDispatchSucceeded(claude, raced.requestId);
  await network.markDispatchSucceeded(claude, expired.requestId);
  store.settleRequestId = raced.requestId;
  now += 11;

  const swept = await network.sweepExpiredRequests();
  assert.deepEqual(swept.map((request) => request.requestId), [expired.requestId]);
  assert.equal((await network.status(claude, raced.requestId)).status, "completed");
});

test("dispatch success is idempotent when the receiver finished before the lifecycle tap", async () => {
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "fast receiver" },
  });
  const completed = await network.completeTrustedReceiverThread(codex.threadId, request.requestId, {
    text: "already finished",
  });

  const afterTap = await network.markDispatchSucceeded(claude, request.requestId);
  assert.deepEqual(afterTap, completed);
  assert.equal(afterTap.status, "completed");
  assert.deepEqual(afterTap.result, { text: "already finished" });
});

test("the default correlated wait does not time out a healthy in-flight receiver", async () => {
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex]),
    requestLeaseMs: 5,
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "wait for an ordinary long turn" },
  });
  await network.subscribe(codex);
  const waiting = network.waitForResult(claude, request.requestId);

  await new Promise((resolve) => setTimeout(resolve, 15));
  await network.completeTrustedReceiverThread(codex.threadId, request.requestId, {
    text: "correct late result",
  });

  const completed = await waiting;
  assert.equal(completed.status, "completed");
  assert.deepEqual(completed.result, { text: "correct late result" });
});

test("authority checks prevent third-party reads and non-receiver completion", async () => {
  const third: PeerIdentity = {
    peerId: "codex:codex-session-2",
    threadId: "thread-third",
    providerName: "codex",
    providerInstanceId: "codex-secondary",
    providerSessionId: "codex-session-2",
    transcriptPath: "/transcripts/codex-session-2.jsonl",
    cwd: "/work/third",
  };
  const network = new ComsNet({
    store: new InMemoryComsNetStore(),
    peers: new StaticPeerDirectory([claude, codex, third]),
  });
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "private" },
  });

  await assert.rejects(network.status(third, request.requestId), /not authorized/i);
  await assert.rejects(network.complete(third, request.requestId, { text: "steal" }), /not authorized/i);
});

test("payload size is bounded before persistence", async () => {
  const network = makeNetwork(32);
  await assert.rejects(
    network.send(claude, {
      targetPeerId: codex.peerId,
      kind: "task",
      payload: { text: "x".repeat(100) },
    }),
    (error: unknown) => error instanceof ComsNetError && error.code === "PAYLOAD_TOO_LARGE",
  );
});

test("completed requests survive a process reconstruction and return without polling", async () => {
  const folder = await mkdtemp(join(tmpdir(), "coms-net-test-"));
  const storePath = join(folder, "requests.json");
  try {
    const first = new ComsNet({
      store: new JsonFileComsNetStore(storePath),
      peers: new StaticPeerDirectory([claude, codex]),
    });
    const request = await first.send(claude, {
      targetPeerId: codex.peerId,
      kind: "task",
      payload: { text: "persist" },
    });
    await first.complete(codex, request.requestId, { text: "landed" });

    const restarted = new ComsNet({
      store: new JsonFileComsNetStore(storePath),
      peers: new StaticPeerDirectory([claude, codex]),
    });
    const result = await restarted.waitForResult(claude, request.requestId);
    assert.deepEqual(result.result, { text: "landed" });
  } finally {
    await rm(folder, { recursive: true, force: true });
  }
});

test("a sender records a failed dispatch as one durable terminal result", async () => {
  const network = makeNetwork();
  const request = await network.send(claude, {
    targetPeerId: codex.peerId,
    kind: "task",
    payload: { text: "cannot launch" },
  });

  const failed = await network.failDispatch(claude, request.requestId, "receiver launch refused");
  assert.equal(failed.status, "failed");
  assert.equal(failed.error, "receiver launch refused");
  assert.equal((await network.waitForResult(claude, request.requestId)).status, "failed");
  await assert.rejects(
    network.failDispatch(claude, request.requestId, "second failure"),
    (error: unknown) => error instanceof ComsNetError && error.code === "ALREADY_TERMINAL",
  );
  await assert.rejects(
    network.failDispatch(codex, request.requestId, "receiver cannot rewrite sender failure"),
    (error: unknown) => error instanceof ComsNetError && error.code === "NOT_AUTHORIZED",
  );
});

test("typed capability endpoints register without carrying credentials", async () => {
  const network = makeNetwork();
  network.registerCapability({
    capabilityId: "linear.issue.read",
    ownerPeerId: codex.peerId,
    requestKind: "linear.issue.read.v1",
  });
  const capability = network.getCapability("linear.issue.read");
  assert.deepEqual(capability, {
    capabilityId: "linear.issue.read",
    ownerPeerId: codex.peerId,
    requestKind: "linear.issue.read.v1",
  });
  assert.equal(JSON.stringify(capability).toLowerCase().includes("token"), false);
  assert.equal(JSON.stringify(capability).toLowerCase().includes("secret"), false);
});
