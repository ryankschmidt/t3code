import { randomUUID } from "node:crypto";
import { mkdir, readFile, rename, writeFile } from "node:fs/promises";
import { dirname } from "node:path";

export type ProviderName = "claudeAgent" | "codex" | (string & {});

export interface PeerIdentity {
  readonly peerId: string;
  readonly threadId: string;
  readonly providerName: ProviderName;
  readonly providerInstanceId: string;
  readonly providerSessionId: string;
  /**
   * Native transcript metadata when the owning server has projected it.
   *
   * Transport membership must not depend on this value: a live provider can
   * receive its server-issued communication credential before its native
   * runtime reports a transcript location.
   */
  readonly transcriptPath?: string;
  readonly cwd: string;
}

export type ComsNetRequestStatus = "queued" | "delivered" | "completed" | "failed";

export interface ComsNetRequest {
  readonly requestId: string;
  readonly senderPeerId: string;
  readonly senderThreadId: string;
  readonly receiverPeerId: string;
  readonly receiverThreadId: string;
  readonly kind: string;
  readonly payload: unknown;
  readonly status: ComsNetRequestStatus;
  readonly createdAt: string;
  readonly deliveredAt?: string;
  readonly lastClaimedAt?: string;
  readonly completedAt?: string;
  readonly result?: unknown;
  readonly error?: string;
}

export interface SendInput {
  readonly targetPeerId: string;
  readonly kind: string;
  readonly payload: unknown;
}

export interface CapabilityEndpoint {
  readonly capabilityId: string;
  readonly ownerPeerId: string;
  readonly requestKind: string;
}

export interface WaitForResultOptions {
  readonly signal?: AbortSignal;
  readonly timeoutMs?: number;
}

export type SubscribeOptions = WaitForResultOptions;

export interface PeerDirectory {
  list(): Promise<ReadonlyArray<PeerIdentity>>;
  get(peerId: string): Promise<PeerIdentity | undefined>;
}

export interface ComsNetStore {
  get(requestId: string): Promise<ComsNetRequest | undefined>;
  list(): Promise<ReadonlyArray<ComsNetRequest>>;
  listForReceiver(receiverPeerId: string): Promise<ReadonlyArray<ComsNetRequest>>;
  insert(request: ComsNetRequest): Promise<void>;
  replace(request: ComsNetRequest): Promise<void>;
}

export class ComsNetError extends Error {
  constructor(
    readonly code:
      | "UNKNOWN_PEER"
      | "PAYLOAD_TOO_LARGE"
      | "NOT_FOUND"
      | "NOT_AUTHORIZED"
      | "ALREADY_TERMINAL"
      | "INVALID_REQUEST",
    message: string,
  ) {
    super(message);
    this.name = "ComsNetError";
  }
}

export class InMemoryComsNetStore implements ComsNetStore {
  protected readonly requests = new Map<string, ComsNetRequest>();

  async get(requestId: string): Promise<ComsNetRequest | undefined> {
    return this.requests.get(requestId);
  }
  async list(): Promise<ReadonlyArray<ComsNetRequest>> {
    return [...this.requests.values()].sort((left, right) => left.createdAt.localeCompare(right.createdAt));
  }
  async listForReceiver(receiverPeerId: string): Promise<ReadonlyArray<ComsNetRequest>> {
    return [...this.requests.values()]
      .filter((request) => request.receiverPeerId === receiverPeerId)
      .sort((left, right) => left.createdAt.localeCompare(right.createdAt));
  }
  async insert(request: ComsNetRequest): Promise<void> {
    if (this.requests.has(request.requestId)) {
      throw new ComsNetError("INVALID_REQUEST", `request ${request.requestId} already exists`);
    }
    this.requests.set(request.requestId, request);
  }
  async replace(request: ComsNetRequest): Promise<void> {
    if (!this.requests.has(request.requestId)) {
      throw new ComsNetError("NOT_FOUND", `request ${request.requestId} was not found`);
    }
    this.requests.set(request.requestId, request);
  }
}

export class JsonFileComsNetStore implements ComsNetStore {
  private operation = Promise.resolve();

  constructor(readonly path: string) {
    if (path.length === 0) throw new ComsNetError("INVALID_REQUEST", "store path is required");
  }

  async get(requestId: string): Promise<ComsNetRequest | undefined> {
    return this.withLock(async () => (await this.readAll()).find((request) => request.requestId === requestId));
  }

  async list(): Promise<ReadonlyArray<ComsNetRequest>> {
    return this.withLock(async () =>
      (await this.readAll()).sort((left, right) => left.createdAt.localeCompare(right.createdAt)),
    );
  }

  async listForReceiver(receiverPeerId: string): Promise<ReadonlyArray<ComsNetRequest>> {
    return this.withLock(async () =>
      (await this.readAll())
        .filter((request) => request.receiverPeerId === receiverPeerId)
        .sort((left, right) => left.createdAt.localeCompare(right.createdAt)),
    );
  }

  async insert(request: ComsNetRequest): Promise<void> {
    return this.withLock(async () => {
      const requests = await this.readAll();
      if (requests.some((entry) => entry.requestId === request.requestId)) {
        throw new ComsNetError("INVALID_REQUEST", `request ${request.requestId} already exists`);
      }
      await this.writeAll([...requests, request]);
    });
  }

  async replace(request: ComsNetRequest): Promise<void> {
    return this.withLock(async () => {
      const requests = await this.readAll();
      const index = requests.findIndex((entry) => entry.requestId === request.requestId);
      if (index < 0) throw new ComsNetError("NOT_FOUND", `request ${request.requestId} was not found`);
      const next = [...requests];
      next[index] = request;
      await this.writeAll(next);
    });
  }

  private async readAll(): Promise<Array<ComsNetRequest>> {
    try {
      const decoded: unknown = JSON.parse(await readFile(this.path, "utf8"));
      if (!Array.isArray(decoded)) throw new Error("store root is not an array");
      return decoded as Array<ComsNetRequest>;
    } catch (error) {
      if ((error as NodeJS.ErrnoException).code === "ENOENT") return [];
      throw error;
    }
  }

  private async writeAll(requests: ReadonlyArray<ComsNetRequest>): Promise<void> {
    await mkdir(dirname(this.path), { recursive: true });
    const temporary = `${this.path}.${process.pid}.${randomUUID()}.tmp`;
    await writeFile(temporary, `${JSON.stringify(requests, null, 2)}\n`, { mode: 0o600 });
    await rename(temporary, this.path);
  }

  private async withLock<T>(operation: () => Promise<T>): Promise<T> {
    const previous = this.operation;
    let release!: () => void;
    this.operation = new Promise<void>((resolve) => {
      release = resolve;
    });
    await previous;
    try {
      return await operation();
    } finally {
      release();
    }
  }
}

export class StaticPeerDirectory implements PeerDirectory {
  constructor(readonly peers: ReadonlyArray<PeerIdentity>) {}
  async list(): Promise<ReadonlyArray<PeerIdentity>> {
    return this.peers;
  }
  async get(peerId: string): Promise<PeerIdentity | undefined> {
    return this.peers.find((peer) => peer.peerId === peerId);
  }
}

export const MAX_TIMER_DELAY_MS = 2_147_483_647;

export const clampTimerDelayMs = (delayMs: number): number =>
  Math.min(MAX_TIMER_DELAY_MS, Math.max(0, delayMs));

export class ComsNet {
  private readonly capabilities = new Map<string, CapabilityEndpoint>();
  private readonly waiters = new Map<
    string,
    Set<{ readonly resolve: (request: ComsNetRequest) => void; readonly reject: (error: Error) => void }>
  >();
  private readonly receiverWaiters = new Map<
    string,
    Set<{ readonly resolve: (requests: ReadonlyArray<ComsNetRequest>) => void; readonly reject: (error: Error) => void }>
  >();

  constructor(
    readonly options: {
      readonly store: ComsNetStore;
      readonly peers: PeerDirectory;
      readonly maxPayloadBytes?: number;
      readonly deliveryLeaseMs?: number;
      readonly requestLeaseMs?: number;
      readonly receiverTurnLeaseMs?: number;
      readonly now?: () => number;
    },
  ) {}
  async listPeers(): Promise<ReadonlyArray<PeerIdentity>> {
    return this.options.peers.list();
  }

  async send(principal: PeerIdentity, input: SendInput): Promise<ComsNetRequest> {
    await this.assertCurrentPrincipal(principal);
    const target = await this.options.peers.get(input.targetPeerId);
    if (target === undefined) {
      throw new ComsNetError("UNKNOWN_PEER", `target peer ${input.targetPeerId} is not current`);
    }
    if (input.kind.trim().length === 0) {
      throw new ComsNetError("INVALID_REQUEST", "request kind is required");
    }
    this.assertPayloadSize(input.payload);
    const request: ComsNetRequest = {
      requestId: randomUUID(),
      senderPeerId: principal.peerId,
      senderThreadId: principal.threadId,
      receiverPeerId: target.peerId,
      receiverThreadId: target.threadId,
      kind: input.kind,
      payload: input.payload,
      status: "queued",
      createdAt: this.nowIso(),
    };
    await this.options.store.insert(request);
    const receiverWaiters = this.receiverWaiters.get(target.peerId);
    if (receiverWaiters !== undefined) {
      this.receiverWaiters.delete(target.peerId);
      const deliveredAt = this.nowIso();
      const delivered = {
        ...request,
        status: "delivered" as const,
        deliveredAt,
        lastClaimedAt: deliveredAt,
      };
      await this.options.store.replace(delivered);
      for (const waiter of receiverWaiters) waiter.resolve([delivered]);
    }
    return request;
  }

  async subscribe(
    principal: PeerIdentity,
    options: SubscribeOptions = {},
  ): Promise<ReadonlyArray<ComsNetRequest>> {
    await this.assertCurrentPrincipal(principal);
    await this.sweepExpiredRequests();
    const delivered = await this.claimAvailableRequests(principal.peerId);
    if (delivered.length > 0 || (options.timeoutMs === undefined && options.signal === undefined)) {
      return delivered;
    }

    return new Promise<ReadonlyArray<ComsNetRequest>>((resolve, reject) => {
      const waiter = { resolve, reject };
      const current = this.receiverWaiters.get(principal.peerId) ?? new Set();
      current.add(waiter);
      this.receiverWaiters.set(principal.peerId, current);
      let timeout: NodeJS.Timeout | undefined;
      const cleanup = () => {
        if (timeout !== undefined) clearTimeout(timeout);
        options.signal?.removeEventListener("abort", abort);
        const registered = this.receiverWaiters.get(principal.peerId);
        registered?.delete(waiter);
        if (registered?.size === 0) this.receiverWaiters.delete(principal.peerId);
      };
      const abort = () => {
        cleanup();
        reject(new Error(`subscription for ${principal.peerId} aborted`));
      };
      const timedOut = () => {
        cleanup();
        resolve([]);
      };
      const originalResolve = waiter.resolve;
      Object.assign(waiter, {
        resolve: (value: ReadonlyArray<ComsNetRequest>) => {
          cleanup();
          originalResolve(value);
        },
      });
      if (options.signal?.aborted === true) return abort();
      options.signal?.addEventListener("abort", abort, { once: true });
      if (options.timeoutMs !== undefined) timeout = setTimeout(timedOut, options.timeoutMs);
      // A send can land after the first store read but before waiter
      // registration. Re-read once after registration; later sends wake the
      // waiter directly. This closes the race without introducing polling.
      void this.claimAvailableRequests(principal.peerId).then(
        (available) => {
          if (available.length === 0) return;
          cleanup();
          resolve(available);
        },
        (error: unknown) => {
          cleanup();
          reject(error instanceof Error ? error : new Error(String(error)));
        },
      );
    });
  }

  async status(principal: PeerIdentity, requestId: string): Promise<ComsNetRequest> {
    await this.assertCurrentPrincipal(principal);
    const request = await this.requireRequest(requestId);
    this.assertParticipant(principal, request);
    return request;
  }

  async complete(
    principal: PeerIdentity,
    requestId: string,
    result: unknown,
  ): Promise<ComsNetRequest> {
    await this.assertCurrentPrincipal(principal);
    const request = await this.requireRequest(requestId);
    if (request.receiverPeerId !== principal.peerId) {
      throw new ComsNetError("NOT_AUTHORIZED", "principal is not authorized to complete this request");
    }
    if (request.status === "completed" || request.status === "failed") {
      throw new ComsNetError("ALREADY_TERMINAL", `request ${requestId} is already terminal`);
    }
    this.assertPayloadSize(result);
    const completed: ComsNetRequest = {
      ...request,
      status: "completed",
      result,
      completedAt: this.nowIso(),
    };
    await this.options.store.replace(completed);
    const waiters = this.waiters.get(requestId);
    if (waiters !== undefined) {
      this.waiters.delete(requestId);
      for (const waiter of waiters) waiter.resolve(completed);
    }
    return completed;
  }

  async failDispatch(
    principal: PeerIdentity,
    requestId: string,
    error: string,
  ): Promise<ComsNetRequest> {
    await this.assertCurrentPrincipal(principal);
    const request = await this.requireRequest(requestId);
    if (request.senderPeerId !== principal.peerId) {
      throw new ComsNetError("NOT_AUTHORIZED", "only the request sender can record dispatch failure");
    }
    if (request.status === "completed" || request.status === "failed") {
      throw new ComsNetError("ALREADY_TERMINAL", `request ${requestId} is already terminal`);
    }
    return this.failRequest(request, error, "dispatch failure");
  }

  async markDispatchSucceeded(
    principal: PeerIdentity,
    requestId: string,
  ): Promise<ComsNetRequest> {
    await this.assertCurrentPrincipal(principal);
    const request = await this.requireRequest(requestId);
    if (request.senderPeerId !== principal.peerId) {
      throw new ComsNetError("NOT_AUTHORIZED", "only the request sender can record dispatch success");
    }
    // A very fast receiver can settle between engine.dispatch returning and
    // the sender lifecycle tap. That terminal row is already the successful
    // outcome the tap exists to protect; never turn it into a false send error.
    if (request.status === "completed" || request.status === "failed") return request;
    if (request.status === "delivered") return request;
    const deliveredAt = this.nowIso();
    const delivered: ComsNetRequest = {
      ...request,
      status: "delivered",
      deliveredAt,
      lastClaimedAt: deliveredAt,
    };
    await this.options.store.replace(delivered);
    return delivered;
  }

  async failTrustedReceiverThread(
    receiverThreadId: string,
    requestId: string,
    error: string,
  ): Promise<ComsNetRequest> {
    const request = await this.requireRequest(requestId);
    if (request.receiverThreadId !== receiverThreadId) {
      throw new ComsNetError("NOT_AUTHORIZED", "failed turn does not belong to the request receiver");
    }
    const receiver = (await this.options.peers.list()).find(
      (peer) => peer.threadId === receiverThreadId && peer.peerId === request.receiverPeerId,
    );
    if (receiver === undefined) {
      throw new ComsNetError("UNKNOWN_PEER", "failed turn receiver is no longer a current peer");
    }
    return this.failRequest(request, error, "receiver failure");
  }

  async sweepExpiredRequests(): Promise<ReadonlyArray<ComsNetRequest>> {
    const requestLeaseMs = this.options.requestLeaseMs ?? 5 * 60_000;
    const receiverTurnLeaseMs = this.options.receiverTurnLeaseMs ?? 4 * 60 * 60_000;
    const expired: Array<ComsNetRequest> = [];
    for (const candidate of await this.options.store.list()) {
      // The list is a snapshot. A receiver can settle one row while the sweep
      // is awaiting another store operation, so always re-read before making
      // a terminal transition and treat a lost terminal race as success.
      const request = await this.options.store.get(candidate.requestId);
      if (request === undefined || request.status === "completed" || request.status === "failed") continue;
      // The request lease bounds time waiting for a receiver to claim the
      // request. Once delivered, an ordinary agent turn may legitimately run
      // longer than that queue lease; expiring it would record a false
      // terminal failure while the receiver is still working.
      if (request.status === "queued") {
        if (this.nowMs() - Date.parse(request.createdAt) < requestLeaseMs) continue;
        try {
          expired.push(
            await this.failRequest(
              request,
              `request lease expired after ${requestLeaseMs}ms`,
              "lease expiry",
            ),
          );
        } catch (error) {
          if (!(error instanceof ComsNetError) || error.code !== "ALREADY_TERMINAL") throw error;
        }
        continue;
      }
      if (request.status !== "delivered") continue;
      const deliveredAt = request.deliveredAt ?? request.createdAt;
      if (this.nowMs() - Date.parse(deliveredAt) < receiverTurnLeaseMs) continue;
      try {
        expired.push(
          await this.failRequest(
            request,
            `receiver turn lease expired after ${receiverTurnLeaseMs}ms without a settled result`,
            "receiver turn lease expiry",
          ),
        );
      } catch (error) {
        if (!(error instanceof ComsNetError) || error.code !== "ALREADY_TERMINAL") throw error;
      }
    }
    return expired;
  }

  async completeTrustedReceiverThread(
    receiverThreadId: string,
    requestId: string,
    result: unknown,
  ): Promise<ComsNetRequest> {
    const request = await this.requireRequest(requestId);
    if (request.receiverThreadId !== receiverThreadId) {
      throw new ComsNetError("NOT_AUTHORIZED", "finished turn does not belong to the request receiver");
    }
    const receiver = (await this.options.peers.list()).find(
      (peer) => peer.threadId === receiverThreadId && peer.peerId === request.receiverPeerId,
    );
    if (receiver === undefined) {
      throw new ComsNetError("UNKNOWN_PEER", "finished turn receiver is no longer a current peer");
    }
    return this.complete(receiver, requestId, result);
  }

  async waitForResult(
    principal: PeerIdentity,
    requestId: string,
    options: WaitForResultOptions = {},
  ): Promise<ComsNetRequest> {
    await this.sweepExpiredRequests();
    const request = await this.status(principal, requestId);
    if (request.status === "completed" || request.status === "failed") return request;

    return new Promise<ComsNetRequest>((resolve, reject) => {
      const waiter = { resolve, reject };
      const current = this.waiters.get(requestId) ?? new Set();
      current.add(waiter);
      this.waiters.set(requestId, current);

      let timeout: NodeJS.Timeout | undefined;
      let leaseTimer: NodeJS.Timeout | undefined;
      const cleanup = () => {
        if (timeout !== undefined) clearTimeout(timeout);
        if (leaseTimer !== undefined) clearTimeout(leaseTimer);
        options.signal?.removeEventListener("abort", abort);
        const registered = this.waiters.get(requestId);
        registered?.delete(waiter);
        if (registered?.size === 0) this.waiters.delete(requestId);
      };
      const abort = () => {
        cleanup();
        reject(new Error(`wait for ${requestId} aborted`));
      };
      const timedOut = () => {
        void this.status(principal, requestId).then(
          (currentRequest) => {
            cleanup();
            if (currentRequest.status === "completed" || currentRequest.status === "failed") {
              resolve(currentRequest);
              return;
            }
            reject(new Error(`wait for ${requestId} timed out`));
          },
          (error: unknown) => {
            cleanup();
            reject(error instanceof Error ? error : new Error(String(error)));
          },
        );
      };
      const armLeaseTimer = (currentRequest: ComsNetRequest) => {
        if (currentRequest.status === "completed" || currentRequest.status === "failed") return;
        const leaseMs =
          currentRequest.status === "queued"
            ? (this.options.requestLeaseMs ?? 5 * 60_000)
            : (this.options.receiverTurnLeaseMs ?? 4 * 60 * 60_000);
        const leaseStartedAt =
          currentRequest.status === "queued"
            ? currentRequest.createdAt
            : (currentRequest.deliveredAt ?? currentRequest.createdAt);
        const remainingMs = clampTimerDelayMs(
          Date.parse(leaseStartedAt) + leaseMs - this.nowMs(),
        );
        leaseTimer = setTimeout(() => {
          void (async () => {
            try {
              await this.sweepExpiredRequests();
              const afterSweep = await this.status(principal, requestId);
              if (afterSweep.status === "completed" || afterSweep.status === "failed") {
                cleanup();
                resolve(afterSweep);
                return;
              }
              armLeaseTimer(afterSweep);
            } catch (error) {
              cleanup();
              reject(error instanceof Error ? error : new Error(String(error)));
            }
          })();
        }, remainingMs);
      };
      const originalResolve = waiter.resolve;
      Object.assign(waiter, {
        resolve: (value: ComsNetRequest) => {
          cleanup();
          originalResolve(value);
        },
      });
      if (options.signal?.aborted === true) return abort();
      options.signal?.addEventListener("abort", abort, { once: true });
      // An omitted timeout means one correlated wait until the receiver's
      // ordinary turn reaches a terminal result. A caller-supplied timeout
      // stops only this waiter; it never mutates the durable request.
      if (options.timeoutMs !== undefined) timeout = setTimeout(timedOut, options.timeoutMs);
      else armLeaseTimer(request);
      // Completion can land after the initial status read but before this
      // waiter is registered. Re-read once after registration: a terminal
      // row resolves immediately; a later completion wakes this waiter.
      void this.status(principal, requestId).then(
        (currentRequest) => {
          if (currentRequest.status === "completed" || currentRequest.status === "failed") {
            cleanup();
            resolve(currentRequest);
          }
        },
        (error: unknown) => {
          cleanup();
          reject(error instanceof Error ? error : new Error(String(error)));
        },
      );
    });
  }

  registerCapability(endpoint: CapabilityEndpoint): void {
    if (
      endpoint.capabilityId.trim().length === 0 ||
      endpoint.ownerPeerId.trim().length === 0 ||
      endpoint.requestKind.trim().length === 0
    ) {
      throw new ComsNetError("INVALID_REQUEST", "capability fields are required");
    }
    this.capabilities.set(endpoint.capabilityId, { ...endpoint });
  }

  getCapability(capabilityId: string): CapabilityEndpoint | undefined {
    return this.capabilities.get(capabilityId);
  }

  private async assertCurrentPrincipal(principal: PeerIdentity): Promise<void> {
    const current = await this.options.peers.get(principal.peerId);
    if (
      current === undefined ||
      current.providerSessionId !== principal.providerSessionId ||
      current.threadId !== principal.threadId
    ) {
      throw new ComsNetError("NOT_AUTHORIZED", "principal is not a current server-derived peer");
    }
  }

  private async requireRequest(requestId: string): Promise<ComsNetRequest> {
    const request = await this.options.store.get(requestId);
    if (request === undefined) throw new ComsNetError("NOT_FOUND", `request ${requestId} was not found`);
    return request;
  }

  private async failRequest(
    request: ComsNetRequest,
    error: string,
    label: string,
  ): Promise<ComsNetRequest> {
    if (request.status === "completed" || request.status === "failed") {
      throw new ComsNetError("ALREADY_TERMINAL", `request ${request.requestId} is already terminal`);
    }
    const reason = error.trim();
    if (reason.length === 0) {
      throw new ComsNetError("INVALID_REQUEST", `${label} requires a reason`);
    }
    const failed: ComsNetRequest = {
      ...request,
      status: "failed",
      error: reason,
      completedAt: this.nowIso(),
    };
    await this.options.store.replace(failed);
    const waiters = this.waiters.get(request.requestId);
    if (waiters !== undefined) {
      this.waiters.delete(request.requestId);
      for (const waiter of waiters) waiter.resolve(failed);
    }
    return failed;
  }

  private async claimAvailableRequests(receiverPeerId: string): Promise<ReadonlyArray<ComsNetRequest>> {
    const deliveryLeaseMs = this.options.deliveryLeaseMs ?? 60_000;
    const available = (await this.options.store.listForReceiver(receiverPeerId)).filter((request) => {
      if (request.status === "queued") return true;
      if (request.status !== "delivered" || request.deliveredAt === undefined) return false;
      return this.nowMs() - Date.parse(request.lastClaimedAt ?? request.deliveredAt) >= deliveryLeaseMs;
    });
    const delivered: Array<ComsNetRequest> = [];
    for (const request of available) {
      const claimedAt = this.nowIso();
      const next: ComsNetRequest = {
        ...request,
        status: "delivered",
        deliveredAt: request.deliveredAt ?? claimedAt,
        lastClaimedAt: claimedAt,
      };
      await this.options.store.replace(next);
      delivered.push(next);
    }
    return delivered;
  }

  private nowMs(): number {
    return this.options.now?.() ?? Date.now();
  }

  private nowIso(): string {
    return new Date(this.nowMs()).toISOString();
  }

  private assertParticipant(principal: PeerIdentity, request: ComsNetRequest): void {
    if (request.senderPeerId !== principal.peerId && request.receiverPeerId !== principal.peerId) {
      throw new ComsNetError("NOT_AUTHORIZED", "principal is not authorized to read this request");
    }
  }

  private assertPayloadSize(payload: unknown): void {
    const bytes = Buffer.byteLength(JSON.stringify(payload) ?? "null", "utf8");
    if (bytes > (this.options.maxPayloadBytes ?? 64 * 1024)) {
      throw new ComsNetError(
        "PAYLOAD_TOO_LARGE",
        `payload is ${bytes} bytes; maximum is ${this.options.maxPayloadBytes ?? 64 * 1024}`,
      );
    }
  }
}
