/**
 * Task outcome ledger — the boundary between "the receiver's turn finished" and
 * "the task's outcome is accepted".
 *
 * WHY THIS FILE EXISTS, measured in the ThroughLine fork on 2026-09-13:
 *   - ComsNet's status union is `queued | delivered | completed | failed`
 *     (src/index.ts:24). There is no state for an accepted outcome.
 *   - The projection pipeline calls `completeFinishedTurn(threadId, requestId,
 *     { text: assistantMessage.text, assistantMessageId, turnId })` when the
 *     receiver's turn settles (apps/server/src/orchestration/Layers/
 *     ProjectionPipeline.ts ~1258-1280). The receiver's finished paragraph IS
 *     the request's `result`, and `ComsNet.complete` marks it `completed`.
 *   So a confident reply that changed nothing on disk completes the task.
 *
 * WHAT THIS LEDGER SEPARATES, as four transitions that never collapse:
 *   1. delivery       — the request text reached the receiver's thread.
 *   2. turn finished  — the receiver's provider turn settled (text may exist).
 *   3. result claimed — the receiver submitted a structured ExecutionResult
 *                       with evidence references, through comsnet_result.
 *   4. acceptance     — an acceptor that is neither the sender nor the
 *                       receiver ran the task's acceptance checks and recorded
 *                       observed values; the ledger, not the acceptor's prose,
 *                       derives accepted | rejected from those observations.
 *
 * WHAT IT DOES NOT OWN: message transport (ComsNet core), turn start and the
 * turn-start door (the orchestration decider), provider execution, the
 * semantic content of any check (an acceptor holds that), and thread
 * lifecycle (ThroughLine). It holds no I/O; the journal is injected so the
 * same transitions replay identically after an interruption.
 *
 * The ledger is a pure function of its journal. Rebuilding from the journal
 * after a crash yields the same state, which is what makes "interruption
 * cannot silently lose the task" a test rather than a promise.
 */

export type OutcomeState =
  | "admitted"
  | "delivered"
  | "turn_finished"
  | "result_claimed"
  | "accepted"
  | "rejected"
  | "failed";

/** One mechanical or judged check the task must pass to be accepted. */
export interface AcceptanceCheck {
  readonly checkId: string;
  /** mechanical: the acceptor observes a value and compares; judged: an outside judge rules. */
  readonly kind: "mechanical" | "judged";
  /** What the acceptor must observe (a sha256, an exit code, a path existing, a judge verdict). */
  readonly expect: string;
  readonly description: string;
}

/** The bounded task as admitted. Written once; never mutated by the receiver. */
export interface TaskContract {
  readonly requestId: string;
  readonly taskId: string;
  readonly operatorTargetId: string;
  readonly senderPeerId: string;
  readonly receiverPeerId: string;
  readonly acceptance: ReadonlyArray<AcceptanceCheck>;
  /**
   * True when completing the task performs an act that must not repeat
   * (a ship request, a message to the operator, a credential cutover). A
   * consequential task requires an idempotency key on its result claim.
   */
  readonly consequential: boolean;
}

/** What the receiver returns. Prose alone is not a result. */
export interface ExecutionResult {
  readonly requestId: string;
  readonly receiverPeerId: string;
  /** Absolute paths or receipt ids the acceptor can open cold. At least one. */
  readonly evidence: ReadonlyArray<string>;
  /** Required when the contract is consequential; the act it names ran once. */
  readonly idempotencyKey?: string;
  readonly summary?: string;
}

export interface CheckObservation {
  readonly checkId: string;
  /** The value the acceptor actually observed, never the receiver's claim. */
  readonly observed: string;
}

export interface AcceptanceVerdict {
  readonly requestId: string;
  /** Must differ from both senderPeerId and receiverPeerId. */
  readonly acceptorPeerId: string;
  readonly observations: ReadonlyArray<CheckObservation>;
}

export type OutcomeEvent =
  | { readonly type: "admitted"; readonly contract: TaskContract; readonly at: string }
  | { readonly type: "delivered"; readonly requestId: string; readonly receiverTurnId: string; readonly at: string }
  | { readonly type: "turn_finished"; readonly requestId: string; readonly receiverTurnId: string; readonly text: string | null; readonly at: string }
  | { readonly type: "result_claimed"; readonly result: ExecutionResult; readonly at: string }
  | { readonly type: "consequential_committed"; readonly requestId: string; readonly idempotencyKey: string; readonly at: string }
  | { readonly type: "acceptance_recorded"; readonly verdict: AcceptanceVerdict; readonly outcome: "accepted" | "rejected"; readonly at: string }
  | { readonly type: "failed"; readonly requestId: string; readonly reason: string; readonly at: string };

export interface OutcomeJournal {
  append(event: OutcomeEvent): void;
  readAll(): ReadonlyArray<OutcomeEvent>;
}

export class InMemoryOutcomeJournal implements OutcomeJournal {
  private readonly events: Array<OutcomeEvent> = [];
  append(event: OutcomeEvent): void {
    this.events.push(event);
  }
  readAll(): ReadonlyArray<OutcomeEvent> {
    return [...this.events];
  }
}

export type OutcomeErrorCode =
  | "UNKNOWN_REQUEST"
  | "INVALID_TRANSITION"
  | "NO_RESULT_CLAIMED"
  | "NO_EVIDENCE"
  | "NOT_INDEPENDENT"
  | "WRONG_RECEIVER"
  | "IDEMPOTENCY_KEY_REQUIRED"
  | "CHECK_NOT_OBSERVED";

export class OutcomeError extends Error {
  constructor(
    readonly code: OutcomeErrorCode,
    message: string,
  ) {
    super(message);
    this.name = "OutcomeError";
  }
}

export interface TaskOutcome {
  readonly contract: TaskContract;
  readonly state: OutcomeState;
  readonly receiverTurnIds: ReadonlyArray<string>;
  readonly finishedText: string | null;
  readonly result: ExecutionResult | null;
  readonly committedKeys: ReadonlyArray<string>;
  readonly verdict: AcceptanceVerdict | null;
  readonly failureReason: string | null;
}

/** True only for the one state that means the task's outcome is accepted. */
export const isAccepted = (outcome: TaskOutcome): boolean => outcome.state === "accepted";

/** True for every state that still owes work; a finished turn is still open. */
export const isOpen = (outcome: TaskOutcome): boolean =>
  outcome.state !== "accepted" && outcome.state !== "rejected" && outcome.state !== "failed";

const TERMINAL: ReadonlySet<OutcomeState> = new Set(["accepted", "rejected", "failed"]);

export class OutcomeLedger {
  private readonly outcomes = new Map<string, TaskOutcome>();

  constructor(
    private readonly journal: OutcomeJournal,
    private readonly now: () => string = () => new Date().toISOString(),
  ) {
    for (const event of journal.readAll()) this.apply(event);
  }

  get(requestId: string): TaskOutcome {
    const outcome = this.outcomes.get(requestId);
    if (outcome === undefined) throw new OutcomeError("UNKNOWN_REQUEST", `no admitted task for request ${requestId}`);
    return outcome;
  }

  admit(contract: TaskContract): TaskOutcome {
    const existing = this.outcomes.get(contract.requestId);
    if (existing !== undefined) return existing; // re-admission is idempotent
    if (contract.acceptance.length === 0) {
      throw new OutcomeError("INVALID_TRANSITION", "a task with no acceptance checks cannot be admitted");
    }
    return this.record({ type: "admitted", contract, at: this.now() });
  }

  /** Delivery of the same request to the same turn twice is one delivery. */
  deliver(requestId: string, receiverTurnId: string): TaskOutcome {
    const outcome = this.get(requestId);
    if (outcome.receiverTurnIds.includes(receiverTurnId)) return outcome;
    if (TERMINAL.has(outcome.state)) return outcome;
    return this.record({ type: "delivered", requestId, receiverTurnId, at: this.now() });
  }

  /**
   * The receiver's turn settled. This is the transition the fork today treats
   * as completion. Here it can never complete anything: the state moves to
   * `turn_finished` and stays open until a result is claimed and accepted.
   */
  turnFinished(requestId: string, receiverTurnId: string, text: string | null): TaskOutcome {
    const outcome = this.get(requestId);
    if (TERMINAL.has(outcome.state)) return outcome;
    if (outcome.state === "result_claimed") return outcome; // a claim already outranks the paragraph
    return this.record({ type: "turn_finished", requestId, receiverTurnId, text, at: this.now() });
  }

  /**
   * The receiver claims a structured result. Evidence is mandatory. For a
   * consequential task the claim must carry an idempotency key, and the same
   * key is committed at most once regardless of how many times the claim or
   * the delivery repeats.
   */
  claimResult(result: ExecutionResult): TaskOutcome {
    const outcome = this.get(result.requestId);
    if (TERMINAL.has(outcome.state)) return outcome;
    if (result.receiverPeerId !== outcome.contract.receiverPeerId) {
      throw new OutcomeError("WRONG_RECEIVER", "only the admitted receiver may claim a result");
    }
    if (result.evidence.length === 0) {
      throw new OutcomeError("NO_EVIDENCE", "a result without evidence references is a paragraph, not a result");
    }
    if (outcome.contract.consequential && result.idempotencyKey === undefined) {
      throw new OutcomeError("IDEMPOTENCY_KEY_REQUIRED", "a consequential task's result must name its idempotency key");
    }
    if (outcome.state === "result_claimed") return outcome; // duplicate claim: no second act
    let next = this.record({ type: "result_claimed", result, at: this.now() });
    if (outcome.contract.consequential && result.idempotencyKey !== undefined) {
      if (!next.committedKeys.includes(result.idempotencyKey)) {
        next = this.record({
          type: "consequential_committed",
          requestId: result.requestId,
          idempotencyKey: result.idempotencyKey,
          at: this.now(),
        });
      }
    }
    return next;
  }

  /**
   * Acceptance. The acceptor must be independent of sender and receiver, must
   * have observed every check the contract names, and the ledger derives the
   * verdict by comparing observed values to the contract's expectations. The
   * acceptor's opinion is never an input; its observations are.
   */
  recordAcceptance(verdict: AcceptanceVerdict): TaskOutcome {
    const outcome = this.get(verdict.requestId);
    if (TERMINAL.has(outcome.state)) return outcome;
    if (outcome.state !== "result_claimed" || outcome.result === null) {
      throw new OutcomeError("NO_RESULT_CLAIMED", "acceptance requires a claimed result; a finished turn is not one");
    }
    const { senderPeerId, receiverPeerId } = outcome.contract;
    if (verdict.acceptorPeerId === senderPeerId || verdict.acceptorPeerId === receiverPeerId) {
      throw new OutcomeError("NOT_INDEPENDENT", "the acceptor must be neither the sender nor the receiver");
    }
    const observed = new Map(verdict.observations.map((o) => [o.checkId, o.observed] as const));
    for (const check of outcome.contract.acceptance) {
      if (!observed.has(check.checkId)) {
        throw new OutcomeError("CHECK_NOT_OBSERVED", `check ${check.checkId} was not observed`);
      }
    }
    const allPass = outcome.contract.acceptance.every((check) => observed.get(check.checkId) === check.expect);
    return this.record({
      type: "acceptance_recorded",
      verdict,
      outcome: allPass ? "accepted" : "rejected",
      at: this.now(),
    });
  }

  fail(requestId: string, reason: string): TaskOutcome {
    const outcome = this.get(requestId);
    if (TERMINAL.has(outcome.state)) return outcome;
    return this.record({ type: "failed", requestId, reason, at: this.now() });
  }

  private record(event: OutcomeEvent): TaskOutcome {
    this.journal.append(event);
    return this.apply(event);
  }

  private apply(event: OutcomeEvent): TaskOutcome {
    switch (event.type) {
      case "admitted": {
        const outcome: TaskOutcome = {
          contract: event.contract,
          state: "admitted",
          receiverTurnIds: [],
          finishedText: null,
          result: null,
          committedKeys: [],
          verdict: null,
          failureReason: null,
        };
        this.outcomes.set(event.contract.requestId, outcome);
        return outcome;
      }
      case "delivered":
        return this.update(event.requestId, (o) => ({
          ...o,
          state: "delivered",
          receiverTurnIds: [...o.receiverTurnIds, event.receiverTurnId],
        }));
      case "turn_finished":
        return this.update(event.requestId, (o) => ({ ...o, state: "turn_finished", finishedText: event.text }));
      case "result_claimed":
        return this.update(event.result.requestId, (o) => ({ ...o, state: "result_claimed", result: event.result }));
      case "consequential_committed":
        return this.update(event.requestId, (o) => ({ ...o, committedKeys: [...o.committedKeys, event.idempotencyKey] }));
      case "acceptance_recorded":
        return this.update(event.verdict.requestId, (o) => ({ ...o, state: event.outcome, verdict: event.verdict }));
      case "failed":
        return this.update(event.requestId, (o) => ({ ...o, state: "failed", failureReason: event.reason }));
    }
  }

  private update(requestId: string, fn: (o: TaskOutcome) => TaskOutcome): TaskOutcome {
    const next = fn(this.get(requestId));
    this.outcomes.set(requestId, next);
    return next;
  }
}
