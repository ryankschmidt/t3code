---
title: "ComsNet Core Changelog"
description: "Version history for the shared ComsNet transport core."
type: changelog
status: active
created: 2026-08-25
last_updated: 2026-08-25
---

# Changelog

## 0.3.0 — 2026-08-25

- Clamped lease-bound timers to Node.js's supported delay range so a future long lease cannot become a one-millisecond hot loop.
- Added a production-path timer regression test rather than testing the clamp helper alone.
- Preserved the structured `ALREADY_TERMINAL` code through ThroughLine's transport adapter so a terminal race keeps the original dispatch error.
- Derived the dispatch acknowledgement timeout from the durable request lease and made the relationship fail loudly in tests.

## 0.2.0 — 2026-08-25

- Added receiver-owned terminal failure so errored, interrupted, and missing-output turns release the waiting sender with a reason.
- Added bounded request leases and expiring delivery claims so neither an abandoned request nor a restarted receiver can strand work permanently.
- Closed the result wait race with one post-registration store read rather than polling.
- Upgraded the compiled Linux rehearsal to exercise the JSON store and restart recovery.
- Added thirteen core behavior tests, including receiver failure, delivery reclaim, and lease expiry.

## 0.1.0 — 2026-08-25

- Added server-derived peer identity and bounded payload enforcement.
- Added correlated `send`, `subscribe`, `status`, and terminal `result` operations.
- Added authority checks, wait-once delivery, restart recovery, and capability endpoints.
- Added deterministic security and two-direction transport tests plus a compiled rehearsal.
