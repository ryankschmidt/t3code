import { mkdir, writeFile } from "node:fs/promises";

import packageJson from "../package.json" with { type: "json" };

await mkdir(new URL("../dist/", import.meta.url), { recursive: true });
await writeFile(
  new URL("../dist/package.json", import.meta.url),
  `${JSON.stringify(
    {
      name: packageJson.name,
      version: packageJson.version,
      private: true,
      type: "module",
      main: "src/index.js",
      types: "src/index.d.ts",
      exports: { ".": { import: "./src/index.js", types: "./src/index.d.ts" } },
    },
    null,
    2,
  )}\n`,
);
