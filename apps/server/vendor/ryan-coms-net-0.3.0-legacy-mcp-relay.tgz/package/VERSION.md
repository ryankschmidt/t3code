---
title: "ComsNet Core Version"
description: "Current released version of the shared ComsNet transport core."
type: reference
status: active
version: 0.3.0
created: 2026-08-25
last_updated: 2026-08-25
---

# Version 0.3.0

Failure-safe shared TypeScript core with bounded timer scheduling for the ThroughLine Claude–Codex transport rail.
