---
title: "ComsNet Core Tool Contract"
description: "Callable TypeScript contract for correlated agent request/result transport."
type: tool
status: active
version: 0.3.0
created: 2026-08-25
last_updated: 2026-08-25
---

# ComsNet Core Tool Contract

## Provides

- current peer-directory projection;
- server-derived send identity;
- bounded correlated requests;
- wait-once subscriptions and results;
- terminal, anti-loop completion;
- receiver-error terminal completion and bounded request expiry;
- expiring delivery claims that survive receiver restart;
- durable restart recovery;
- typed capability endpoint registration.

## Must not own

- agent summon, lease, resume, or deduplication;
- provider login or credential custody;
- ThroughLine's thread database;
- Linear policy or Work Item Store projection.

## Security boundary

No public input contains `senderPeerId`, a bearer, a token, or a secret. A container adapter derives the principal and passes it directly to the core. Only sender and receiver can read a request. Only the receiver can complete or fail a dispatched request; only the sender can record dispatch failure. A bounded lease converts abandoned requests into explicit terminal failures rather than permanent hangs.
