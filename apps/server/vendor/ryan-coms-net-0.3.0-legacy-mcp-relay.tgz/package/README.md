---
title: "ComsNet Core"
name: "ComsNet Core"
description: "Shared credential-free request/result transport contract consumed by trusted agent containers."
purpose: "Provide bounded correlated agent messaging while leaving thread lifecycle and credentials outside the transport."
type: tool
status: active
version: 0.3.0
created: 2026-08-25
last_updated: 2026-08-25
conceptual_lineage:
  - agent-orchestration
  - boundary-agent
  - credential-ops
operator_target: TGT-2026-08-24-ryan-governed-tower-primary-rpi-greenfield
operator_target_status: admitted
---

# ComsNet Core

ComsNet Core owns four message operations: `send`, `subscribe`, `status`, and `result`. It does not launch, lease, resume, or deduplicate agent containers; ThroughLine owns those thread-lifecycle acts.

The caller never supplies a sender identity. A trusted container adapter passes a server-derived `PeerIdentity`, and the core verifies it against the current peer directory before accepting an operation. ThroughLine's adapter uses its existing per-provider-session MCP credential, not a shared bearer token.

The store contract is replaceable. The shipped JSON store is an atomic, mode-0600 durable store owned by one ThroughLine server process. It supports restart recovery without turning persistence into a separate network service. Receiver delivery claims expire and abandoned requests become explicit terminal failures, so a restart or dead turn cannot leave the sender waiting forever.

## Build and proof

```bash
ryan pkg check /Users/Admin/core-root/vault/01_Projects/workbench/tools/coms-net
corepack pnpm --dir /Users/Admin/core-root/vault/01_Projects/workbench/tools/coms-net run test
corepack pnpm --dir /Users/Admin/core-root/vault/01_Projects/workbench/tools/coms-net run build
corepack pnpm --dir /Users/Admin/core-root/vault/01_Projects/workbench/tools/coms-net run rehearse
```

The raw package-manager form is the measured fallback as of 2026-08-25: `ryan pkg run` currently exits 0 while printing `No projects matched the filters` for this registered workspace member. Do not treat that false green as a build.

Tier 1 is the only edit/build surface. Ship Warden installs compiled files under `/Users/Admin/core-root/src/tools/coms-net/`; consumers run that compiled Tier 2 package.
