import { mkdtemp, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { ComsNet, JsonFileComsNetStore, StaticPeerDirectory, type PeerIdentity } from "./src/index.js";

const claude: PeerIdentity = {
  peerId: "claude:rehearsal",
  threadId: "thread-claude",
  providerName: "claudeAgent",
  providerInstanceId: "claudeAgent",
  providerSessionId: "rehearsal",
  transcriptPath: "/rehearsal/claude.jsonl",
  cwd: "/rehearsal",
};
const codex: PeerIdentity = {
  ...claude,
  peerId: "codex:rehearsal",
  threadId: "thread-codex",
  providerName: "codex",
  providerInstanceId: "codex",
  transcriptPath: "/rehearsal/codex.jsonl",
};
const folder = await mkdtemp(join(tmpdir(), "coms-net-linux-rehearsal-"));
const storePath = join(folder, "requests.json");
try {
  const firstProcess = new ComsNet({
    store: new JsonFileComsNetStore(storePath),
    peers: new StaticPeerDirectory([claude, codex]),
  });
  const request = await firstProcess.send(claude, {
    targetPeerId: codex.peerId,
    kind: "rehearsal.v2",
    payload: { text: "hello durable Linux" },
  });
  await firstProcess.subscribe(codex);
  await firstProcess.complete(codex, request.requestId, { text: "done" });

  const restartedProcess = new ComsNet({
    store: new JsonFileComsNetStore(storePath),
    peers: new StaticPeerDirectory([claude, codex]),
  });
  const result = await restartedProcess.waitForResult(claude, request.requestId);
  if (result.status !== "completed") throw new Error("durable rehearsal did not complete");
  process.stdout.write(
    `${JSON.stringify({ ok: true, durableStore: true, restartRecovery: true, requestId: result.requestId })}\n`,
  );
} finally {
  await rm(folder, { recursive: true, force: true });
}
